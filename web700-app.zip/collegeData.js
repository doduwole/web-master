// collegeData.js

const fs = require('fs');

// Define the Data class to store students and courses
class Data {
  constructor(students, courses) {
    this.students = students;
    this.courses = courses;
  }
}

let dataCollection = null;

// Initialize the data by reading from files and creating an instance of the Data class
function initialize() {
  return new Promise((resolve, reject) => {
    // Read students.json file
    fs.readFile('./data/students.json', 'utf8', (err, studentDataFromFile) => {
      if (err) {
        reject("Unable to read students.json");
        return;
      }

      // Read courses.json file
      fs.readFile('./data/courses.json', 'utf8', (err, courseDataFromFile) => {
        if (err) {
          reject("Unable to read courses.json");
          return;
        }

        // Parse the data from JSON files
        const studentData = JSON.parse(studentDataFromFile);
        const courseData = JSON.parse(courseDataFromFile);

        // Create an instance of the Data class
        dataCollection = new Data(studentData, courseData);

        resolve();
      });
    });
  });
}

// Retrieve all students
function getAllStudents() {
  return new Promise((resolve, reject) => {
    if (dataCollection && dataCollection.students && dataCollection.students.length > 0) {
      resolve(dataCollection.students);
    } else {
      reject("No students found.");
    }
  });
}

// Retrieve TAs
function getTAs() {
  return new Promise((resolve, reject) => {
    if (dataCollection && dataCollection.students && dataCollection.students.length > 0) {
      const tas = dataCollection.students.filter(student => student.TA);
      if (tas.length > 0) {
        resolve(tas);
      } else {
        reject("No TAs found.");
      }
    } else {
      reject("No students found.");
    }
  });
}

// Retrieve all courses
function getCourses() {
  return new Promise((resolve, reject) => {
    if (dataCollection && dataCollection.courses && dataCollection.courses.length > 0) {
      resolve(dataCollection.courses);
    } else {
      reject("No courses found.");
    }
  });
}

// Retrieve students by course
function getStudentsByCourse(course) {
  return new Promise((resolve, reject) => {
    if (dataCollection && dataCollection.students && dataCollection.students.length > 0) {
      const students = dataCollection.students.filter(student => student.course === course);
      if (students.length > 0) {
        resolve(students);
      } else {
        reject("No results returned.");
      }
    } else {
      reject("No students found.");
    }
  });
}

// Retrieve student by number
function getStudentByNum(num) {
  return new Promise((resolve, reject) => {
    if (dataCollection && dataCollection.students && dataCollection.students.length > 0) {
      const student = dataCollection.students.find(student => student.studentNum === num);
      if (student) {
        resolve(student);
      } else {
        reject("No results returned.");
      }
    } else {
      reject("No students found.");
    }
  });
}

module.exports = {
  initialize,
  getAllStudents,
  getTAs,
  getCourses,
  getStudentsByCourse,
  getStudentByNum
};
